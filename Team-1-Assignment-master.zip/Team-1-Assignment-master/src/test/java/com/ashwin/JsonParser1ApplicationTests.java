package com.ashwin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonParser1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
